export default function Dashboard() {
  return (
    <div className="min-h-screen p-6">
      <h2 className="text-2xl font-semibold mb-4">Spending Dashboard</h2>
      <p>Transaction history will appear here.</p>
    </div>
  )
}